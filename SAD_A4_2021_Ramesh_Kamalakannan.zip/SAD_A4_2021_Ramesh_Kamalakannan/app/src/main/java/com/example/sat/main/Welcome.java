package com.example.sat.main;



import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.bumptech.glide.Glide;
import com.example.sdaassign4_2019.R;



public class Welcome extends Fragment {

    /**
     * empty constructor initializes view
     */
    public Welcome() {
        // Required empty public constructor
    }

    /**
     * <pre>onCreateView inflates the fragment view for this welcome tab page</p>
     * @param inflater inflates the layout
     * @param container creates the container that holds the fragment
     * param savedInstanceState bundle saved
     * @return the fragment view</pre>
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_welcome, container, false);
        root.getRootView().setBackgroundColor(getResources().getColor(R.color.myColor));

      
        String imageUrl = "https://firebasestorage.googleapis.com/v0/b/assign4-colin-fleck.appspot.com/o/reading_tree.png?alt=media&token=8a43b541-e5ab-40fe-8c5e-d30820d9a3c6";




        return root;
    }

}
