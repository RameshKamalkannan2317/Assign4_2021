package com.example.sat.main;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.sdaassign4_2019.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;



public class BookList extends Fragment {
    private static final String TAG = "BookList";

    //List that is filled with data retrieved from Firebase and passed to recyclerViewAdapter
    public  final ArrayList<Book> bookData = new ArrayList<>();
    //DB reference for firebase
    DatabaseReference db;

    /**
     * <pre>empty constructor initializes view</pre>
     */
    public BookList() {
        // Required empty public constructor
    }

    /**
     * <pre>onCreateView method builds and inflates this fragment.
     * @param inflater sets the layout.
     * @param container creates a container for the fragment.
     * @param savedInstanceState saves bundle.
     * @return the fragment view.</pre>
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_book_list, container, false);

        //recyclerView declared
        RecyclerView recyclerView = root.findViewById(R.id.bookView_view);

        //RecyclerViewAdapter declared with context and the bookData list
        final LibraryViewAdapter recyclerViewAdapter = new LibraryViewAdapter(getContext(), bookData);

        //Data sent to the LibraryViewAdapter.java file
        recyclerView.setAdapter(recyclerViewAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        /* Firebase reference to the book data and listener that updates the
         * bookData list with the current data in the database
         */
        db = FirebaseDatabase.getInstance().getReference().child("book");
        db.addValueEventListener(new ValueEventListener() {

            /**
             * <pre>OnDataChange method checks the database for any new data and updates
             * the bookDaata object with the current data
             * @param dataSnapshot takes a json snapshot of firebase db ref to book
             *
             *      ref: - https://www.youtube.com/watch?v=18Td7PH_1r8
             *           - SDA course text: CH. 16
             *                     </pre>
             */
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                //loops though the data in DB with ref book
                for(DataSnapshot snapshot: dataSnapshot.getChildren()){

                    //grabs the author, title, imageUrl, availability via help from the JOVO Book.class
                    String author = snapshot.getValue(Book.class).getAuthor();
                    String title = snapshot.getValue(Book.class).getTitle();
                    String url = snapshot.getValue(Book.class).getImageUrl();
                    boolean available = snapshot.getValue(Book.class).getAvailable();
                    Log.i(TAG, "boolean: " + available);

                    //add the data from the database and put into the bookData list object
                    bookData.add(new Book(title, author, url, available));
                }
                //Notify the recyclerView that new data has been set
                recyclerViewAdapter.notifyDataSetChanged();
            }

            /**
             * <pre>Method alerts user with db error if there was a
             * problem receiving the data from the db
             * @param databaseError provides user with Db error. Although none is specified here</pre>
             */
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                //alert user with db error
            }
        });

        return root;
    }


}

