# SDA_Assign4_2020
> Project files for my SDA assignment 4

## Brief
> Build an app of our own design based off the Assignment4 project provided by teacher
- __Purpose__:
  - Familiarize students with:
    - Advanced User Interface features
    - Basic data storage e.g. shared preferences
    - Firebase databse and networking
    - prepare for mobiel application project

## App Description
> A library checkout app for kids.
